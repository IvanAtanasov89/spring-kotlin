## Spring Kotlin Example

To run:

```
$ ./gradlew bootRun
```

Hit the endpoint:

```
curl 'localhost:9000/greeting?name=ivan'
```
