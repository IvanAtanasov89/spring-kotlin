package example

data class Greeting(val id: Long, val content: String)
